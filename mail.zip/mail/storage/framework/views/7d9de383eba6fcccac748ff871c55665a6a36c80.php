

<?php $__env->startSection('content'); ?>
    <div class="container shadow   ">
        <div class="col p-1 mt-5  offset-md-10 ">

            <button class="btn btn-secondary btn-sm" id="showCC"> CC</button>
            <button class="btn btn-secondary btn-sm" id="showBCC"> BCC</button>
            <button class="btn btn-success btn-sm" id="showBCC" onclick="window.location.href='./setting'"> SETTING</button>
        </div>
        <div class="offset-md-3">
            <form action="<?php echo e(route('sendmail')); ?>" id="contactForm" method="POST" class="col-12 col-md-9  "
                enctype="multipart/form-data">

                <?php echo csrf_field(); ?>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <div class="inputBox">
                    <input type="text" class='form-control' name="name" id="subject" placeholder="NAME" />
                    </span>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"> <?php echo e($message); ?> </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <input type="text" class='form-control' name="subject" id="subject" placeholder="Subject" />
                    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"> <?php echo e($message); ?> </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                </div>


                <div class="inputBox">
                    <!-- <input type="email"  placeholder="Receiver Email....." /> -->
                    <textarea class='form-control' id="emailid" name="email" cols="30" rows="1" placeholder="Email"></textarea>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"> <?php echo e($message); ?> </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <small>Use a comma to separate multiple email <br> <br></small>
                </div>


                <div class="showCCbox">
                    <!-- <input type="email"  placeholder="Receiver Email....." /> -->
                    <textarea id="carboncopy" class='form-control' name="carboncopy" cols="30" rows="1" placeholder="CC"></textarea>
                    <!-- <small>Use a comma to separate multiple email  <br> <br></small> -->

                </div>

                <div class="showBCCbox">
                    <!-- <input type="email"  placeholder="Receiver Email....." /> -->
                    <textarea id="blindcarboncopy" class='form-control' name="blindcarboncopy" cols="30" rows="1"
                        placeholder="BCC"></textarea>
                    <!-- <small>Use a comma to separate multiple email  <br> <br></small> -->

                </div>

                <div class="inputBox">
                    <textarea id="msgContent" name='content' class='form-control' cols="30" rows="10" placeholder="Message"></textarea>
                    <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"> <?php echo e($message); ?> </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="inputBox">
                    ADD Attachement
                    <br>
                    <label for="forhtml" class="btn btn-primary btn-sm my-2">SEND FILE AS HTML DOCUMENT </label>
                    <input type="checkbox" name="inputfile" id="forhtml" value="confirm">
                    <br>

                    <input type="file" name="fileupload" id="files" class="form-control">

                    <!-- <input type="text" name="path" id="path"  > -->


                </div>


                <div class="inputBox">
                    <button type="submit" class="btn btn-info mt-3">Submit</button>
                    <br> <br>
                </div>
            </form>



        </div>


    </div>
    <br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Incredible Mack\mail\resources\views/mail.blade.php ENDPATH**/ ?>